#!/bin/bash
set -e

SCRIPT_ROOT=$(cd "$(dirname "$0")" && pwd)

cd "${SCRIPT_ROOT}"

NEW_VERSION=$(cat VERSION_INFO 2>/dev/null || echo "0.0.0")
OLD_VERSION=$(cat /etc/ab_version 2>/dev/null || echo "0.0.0")

echo "🔍 Current version: $OLD_VERSION"
echo "🔍 Target version: $NEW_VERSION"

version_gt() { test "$(printf '%s\n' "$@" | sort -V | head -n 1)" != "$1"; }

if ! version_gt "$NEW_VERSION" "$OLD_VERSION"; then
    echo "Target version is not larger than current version, skip install"
    exit 0
fi

# --- 2. 执行预处理 ---
if [ -f "./pre_install.sh" ]; then
    bash ./pre_install.sh
fi

# --- 3. 自动安装组件 ---
echo "Update software list..."
export DEBIAN_FRONTEND=noninteractive
apt-get update || apt-get install -f -y

# 自动发现并安装 DEB
DEB_FILE=$(ls *.deb | head -n 1 || true)
if [ -n "$DEB_FILE" ]; then
    echo "Install: $DEB_FILE"
    apt-get install -y \
        -o Dpkg::Options::="--force-confdef" \
        -o Dpkg::Options::="--force-confnew" \
        "./$DEB_FILE"
fi

# if [ -d "./configs" ]; then cp -r ./configs/* /etc/myapp/; fi

# --- 4. 执行后置处理 ---
if [ -f "./post_install.sh" ]; then
    bash ./post_install.sh "$NEW_VERSION"
fi

echo "Update finish"
