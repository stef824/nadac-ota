#!/bin/bash
set -e

# 参数 $1 由 update.sh 传入，代表新版本号
NEW_VERSION=$1
VERSION_FILE="/etc/ab_version"

echo "Post Install Start..."

# --- 1. 更新系统版本记录 ---
if [ -z "$NEW_VERSION" ]; then
    if [ -f "./VERSION_INFO" ]; then
        NEW_VERSION=$(cat ./VERSION_INFO)
    else
        echo "No NEW_VERSION"
        exit 1
    fi
fi

echo "$NEW_VERSION" > "$VERSION_FILE"

echo "Cleaning..."
apt-get clean

echo "Post Install Finish"
