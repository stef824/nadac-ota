#!/bin/bash
set -e

echo "Pre install..."

echo "Checking and fixing dpkg interruptions..."

# 检查包是否处于损坏状态 (reinstreq)
if dpkg -s mf-audio-bridge 2>/dev/null | grep -q "reinstreq"; then
    echo "package broken, try to fix database status"

    # 方案 A：如果有当前的 .deb 文件，直接强行安装它来覆盖损坏状态
    DEB_FILE=$(ls *.deb | head -n 1 || true)
    if [ -n "$DEB_FILE" ]; then
        echo "Overwrite: $DEB_FILE"
        dpkg -i --force-all --force-confnew --force-confdef "./$DEB_FILE"
    else
        # 方案 B：如果没有包，只能先从数据库中强行抹除这个损坏的标记
        echo "No deb, try to fix database..."
        # 这一步非常危险但有效，它通过重置状态来骗过 apt
        # 注意：这不会删除文件，只是改状态
        dpkg --remove --force-remove-reinstreq mf-audio-bridge || true
    fi
fi

# --- deps ---
# pkill - procps
echo "Ensuring dependencies for scripts..."
export DEBIAN_FRONTEND=noninteractive
apt-get update || apt-get install -f -y
apt-get install -y \
    -o Dpkg::Options::="--force-confdef" \
    -o Dpkg::Options::="--force-confnew" \
    procps \
    coreutils \
    ca-certificates \
    debian-archive-keyring \
    sed \
    grep

echo "Stop rknpu2..."
systemctl stop rknpu2.service || true
systemctl disable rknpu2.service || true

echo "Stop pipewire..."
pkill -9 pipewire || true
pkill -9 wireplumber || true

echo "Remove Pipewire..."
apt-get remove --purge -y pipewire pipewire-bin pipewire-pulse wireplumber
apt-get autoremove -y

echo "Pre install finish"
